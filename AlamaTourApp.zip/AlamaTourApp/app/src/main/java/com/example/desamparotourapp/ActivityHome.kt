package com.example.desamparotourapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.desamparotourapp.databinding.ActivityHomeBinding

class ActivityHome : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var buttonMap: Map<Button, String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        buttonMap = mapOf(
            binding.btnDonsol to "Donsol",
            binding.btnPilar to "Pilar",
            binding.btnCastilla to "Castilla",
            binding.btnSorsogon to "Sorsogon",
            binding.btnPrietoDiaz to "PrietoDiaz",
            binding.btnGubat to "Gubat",
            binding.btnCasiguran to "Casiguran",
            binding.btnBarcelona to "Barcelona",
            binding.btnJuban to "Juban",
            binding.btnBulusan to "Bulusan",
            binding.btnIrosin to "Irosin",
            binding.btnMagallanes to "Magallanes",
            binding.btnBulan to "Bulan",
            binding.btnSantaMagdalena to "SantaMagdalena",
            binding.btnMatnog to "Matnog"
        )

        for ((button, _) in buttonMap) {
            button.setOnClickListener {
                handleButtonClick(button)
            }
        }

    }

    private fun handleButtonClick(button: Button) {
        val intent = Intent(this, ActivityMunicipality::class.java)
        intent.putExtra("municipality", buttonMap[button] ?: "")
        startActivity(intent)
    }
}