package com.example.desamparotourapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.example.desamparotourapp.databinding.ActivityMunicipalityBinding
import com.google.firebase.firestore.FirebaseFirestore

class ActivityMunicipality : AppCompatActivity() {

    private lateinit var binding: ActivityMunicipalityBinding
    private lateinit var municipalityID: String
    private lateinit var touristSpotsContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMunicipalityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        municipalityID = intent.getStringExtra("municipality").toString().lowercase()
        touristSpotsContainer = findViewById(R.id.touristSpotsContainer)

        // query data from firestore
        FirebaseFirestore.getInstance().collection("municipalities")
            .document(municipalityID)
            .get()
            .addOnFailureListener {
                Toast.makeText(this, "Failed to fetch data from DB", Toast.LENGTH_SHORT).show()
                binding.txtViewMunName.text = "No Internet"
                binding.txtViewNoOfTouristDest.text = "No Internet"
                binding.imgViewLogo.setImageResource(R.drawable.ic_launcher_foreground)
                binding.main.visibility = View.VISIBLE
                return@addOnFailureListener
            }
            .addOnSuccessListener { doc ->
                // Load municipality Name
                val munName = doc.getString("name")
                binding.txtViewMunName.text = munName

                // Load municipality Logo
                val logoUri = doc.getString("logo_uri")
                Glide.with(this)
                    .load(logoUri)
                    .into(binding.imgViewLogo)

                val spots = doc["tourist_spots"] as? List<Map<String, Any>>
                val spotCount = spots?.size ?: 0

                // Load tourist count
                binding.txtViewNoOfTouristDest.text = "$spotCount Tourist Destination"

                // load tourist spots
                spots?.forEach { spot ->
                    val name = spot["name"] as String ?: ""
                    val fee = spot["fee"] as String ?: ""
                    val rating = spot["rating"] as String ?: ""
                    val location = spot["location"] as String ?: ""
                    val description = spot["description"] as String ?: ""
                    val imageUri = spot["image_uri"] as String ?: ""

                    addTouristDestination(location, fee, imageUri, rating, description, name)
                }

                // show content after fetching
                binding.main.visibility = View.VISIBLE

            } // I need to handle errors: failed, no internet connection
            .addOnFailureListener {
                binding.txtViewMunName.text = "No Internet"
                binding.txtViewNoOfTouristDest.text = "No Internet"
                binding.btnReadHistory.isEnabled = false
            }

        // set logo based on municipality
        // set title
        // set number of tourist destinations
    }

    private fun addTouristDestination(
        location: String,
        entranceFee: String, imageUri: String,
        rating: String, description: String, name: String) {

        val itemView = layoutInflater.inflate(R.layout.tourist_spot_item, touristSpotsContainer, false)
        itemView.findViewById<TextView>(R.id.txtViewEntranceFee).text = entranceFee
        itemView.findViewById<TextView>(R.id.txtViewLocation).text = location
        itemView.findViewById<TextView>(R.id.txtViewRating).text = rating

        // Load Pic
        Glide.with(this)
            .load(imageUri)
            .fallback(R.drawable.ic_launcher_foreground)
            .error(R.drawable.ic_launcher_foreground)
            .into(itemView.findViewById(R.id.ImageViewDestinationLogo))

        itemView.findViewById<Button>(R.id.btnReadMoreDestSpot).setOnClickListener {
            val intent = Intent(this, ActivityDestinationDescription::class.java)
            intent.putExtra("name", name)
            intent.putExtra("description", description)
            intent.putExtra("imageUri", imageUri)
            startActivity(intent)
        }

        touristSpotsContainer.addView(itemView)
    }
}